package com.sjj.vip.spring.framework.context;

/**
 * @ClassName SJJApplicationContextAware
 * @Description TODO
 * Author shengjunjie
 * Date 2019/4/26 16:48
 **/
public interface SJJApplicationContextAware {
    void setApplicationContext(SJJApplicationContext applicationContext);
}
