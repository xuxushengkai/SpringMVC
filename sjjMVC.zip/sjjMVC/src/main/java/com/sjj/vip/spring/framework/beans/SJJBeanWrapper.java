package com.sjj.vip.spring.framework.beans;

/**
 * @ClassName SJJBeanWrapper
 * @Description TODO
 * Author shengjunjie
 * Date 2019/4/26 15:56
 **/
public class SJJBeanWrapper {

    private Object wrappedInstance;
    private Class<?> wrappedClass;

    public SJJBeanWrapper(Object wrappedInstance){
        this.wrappedInstance = wrappedInstance;
    }
    public Object getWrappedInstance(){
        return this.wrappedInstance;
    }

    // ���ش����Ժ�� Class
    // ���ܻ������ $Proxy0
    public Class<?> getWrappedClass(){
        return this.wrappedInstance.getClass();
    }
}
