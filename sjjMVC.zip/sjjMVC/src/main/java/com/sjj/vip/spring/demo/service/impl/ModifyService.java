package com.sjj.vip.spring.demo.service.impl;

import com.sjj.vip.spring.demo.service.IModifyService;
import com.sjj.vip.spring.framework.annoation.SJJService;

@SJJService
public class ModifyService implements IModifyService {

    /**
     *新增
     */
    public String add(String name, String addr) {
        return "modifyService add,name=" + name + ",addr=" + addr;
    }

    /**
    *修改
     */
    public String edit(Integer id, String name) {
        return "modifyService edit,id=" + id + ",name=" + name;
    }

    /**
     *删除
     */
    public String remove(Integer id) {
        return "modifyService id=" + id;
    }
}
