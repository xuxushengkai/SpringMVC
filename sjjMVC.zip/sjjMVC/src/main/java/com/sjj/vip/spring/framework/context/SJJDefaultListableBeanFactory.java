package com.sjj.vip.spring.framework.context;

import com.sjj.vip.spring.framework.beans.SJJBeanDefinition;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @ClassName SJJDefaultListableBeanFactory
 * @Description TODO
 * Author shengjunjie
 * Date 2019/4/26 16:38
 **/
public class SJJDefaultListableBeanFactory extends SJJAbstractApplicationContext {
    //�洢ע����Ϣ�� BeanDefinition
    protected final Map<String, SJJBeanDefinition> beanDefinitionMap = new ConcurrentHashMap<String,SJJBeanDefinition>();
}
