package com.sjj.vip.spring.demo.service;

public interface IQueryService {

    /**
     * 查询
     */
    public String query(String name);
}
