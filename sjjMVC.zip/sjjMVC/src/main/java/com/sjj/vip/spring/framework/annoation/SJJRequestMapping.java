package com.sjj.vip.spring.framework.annoation;


import java.lang.annotation.*;


@Target({ElementType.METHOD,ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface SJJRequestMapping {
    String value() default "";
}
