package com.sjj.vip.spring.demo.service.impl;

import com.sjj.vip.spring.demo.service.IQueryService;
import com.sjj.vip.spring.framework.annoation.SJJService;
import lombok.extern.slf4j.Slf4j;

import java.text.SimpleDateFormat;
import java.util.Date;

@Slf4j
@SJJService
public class QueryService implements IQueryService {

    /**
     * 查询
     */
    public String query(String name) {
        SimpleDateFormat sdf = new SimpleDateFormat();
        String time = sdf.format(new Date());
        String json  = "{name:\"" + name + "\",time:\"" + time + "\"}";
        log.info("这是在业务方法中打印的：" + json);
        return json;
    }
}
