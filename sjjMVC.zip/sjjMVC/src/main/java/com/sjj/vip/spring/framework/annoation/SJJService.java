package com.sjj.vip.spring.framework.annoation;

import java.lang.annotation.*;

/**
 * @ClassName sjjService
 * Author shengjunjie
 * Date 2019/4/22 21:41
 **/
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface SJJService {
    String value() default "";
}