package com.sjj.vip.spring.framework.annoation;

import java.lang.annotation.*;

/**
 * �Զ�ע��
 */
@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface SJJAutowired {
    String value() default "";
}