package com.sjj.vip.spring.framework.webmvc.servlet;

import lombok.Getter;
import lombok.Setter;

import java.lang.reflect.Method;
import java.util.regex.Pattern;

/**
 * @ClassName SJJHandlerMapping
 * @Description TODO
 * Author shengjunjie
 * Date 2019/4/29 11:47
 **/
@Setter
@Getter
public class SJJHandlerMapping {

    private Object controller;
    private Method method;
    private Pattern pattern; //url �ķ�װ

    public SJJHandlerMapping(Pattern pattern, Object controller, Method method) {
        this.controller = controller;
        this.method = method;
        this.pattern = pattern;
    }
}
